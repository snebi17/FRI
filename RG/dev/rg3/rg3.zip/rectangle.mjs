export class Rectangle {
	constructor(x, y, w, h) {
		this.boundX = x;
		this.boundY = y;
		this.boundW = w;
		this.boundH = h;
	}
}

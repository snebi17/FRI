UEFI oz. **U**nified **E**xtensible **F**irmware **I**nterface, je novejša množica ukazov firmware-a, ki dandanes v veliki večini že prekosila BIOS v smislu produkcije in popularnosti. Sicer CPE-ji in matične plošče v legacy mode še podpirajo BIOS sisteme, kar pa naj ne bi bilo več za dolgo.

UEFI se razlikuje v procesu, kaj naloži, ko se računalnik prižge. Ta naloži GPT tabelo -> Globalyl Unique Identifiers Partition Table. Iz katere lahko izbiramo kateri operacijski sistem bomo bootali.
![[Pasted image 20221019152615.png]]

Operacijske sisteme lahko nalagamo tudi preko omrežja, to nam ponuja nekaj prednosti, a tudi slabosti. Stroj zaganjamo s [[Bootstrap Protocol#BOOTP]] BOOTP storitvijo

>Prednosti:
- Ne potrebujemo diska na računalniku oz. kakršnegakoli zunanjega storega, za OS
- OS lahko zamenjamo za use računalnike, ki se bootajo preko omrežja, saj to delamo iz centralnega strežnika
>Slabosti:
- Ranljivost
- Počasnost
- Varnost

SNMP oz. Simple Network Management Protocol je protokol za izmenjavo nadzornih informacij med upravljalcem in nadzorovanimi objekti. Podatki o teh se prenašajo med upravljalcem in nadzorovano opremo skladno z definicijo MIB.

Definira dva načina delovanja
>**Zahteva-Odgovor (Koračni protokol)**
>**Obvestilo (Trap message)**

## Oblika Sporočila

## Verzije SNMP

## Varnost


IGMP je bil prvi protokol, ki je implementiral teorije multicast-a. Razvite so bile 3 verzije, ver. 2 je definirana v RFC 2236, ver. 3, to je najnovejša pa v RFC 3376.

IGMP komunikacija poteka med posameznikom in najbližjim razpošiljalnim usmerjevalnikom. Na podlagi te naloge se usmerjevalniki povežejo v razpošiljevalno drevo, da poznajo vse te točke.


![[Pasted image 20221111165634.png]]
![[Pasted image 20221111165649.png]]
![[Pasted image 20221111165703.png]]
![[Pasted image 20221111165719.png]]

## Postopek
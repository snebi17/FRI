Standard je definiran v konceptu imeniških storitev. Ta sestoji iz 4 protokolov:
- Protokol za dostop do imeniške strukture

Imeniška struktura ni definirana s tem kako izgleda, temveč z shemo, kako shemo zapišemo in samimi operacijami nad strukturo. Ne zanima nas kako je to shranjeno, ampak kaj lahko s to zadevo počnemo.

Standard definira imenski prostor in kaj se v njem nahaja (objekti/predmeti). Predmet ima lahko eno ali več ponavljajočih se vrednosti prilastkov. Ter da imeniška struktura sestoji iz enega samega imenika. Posamezne dele imenika se posluzujejo različni strežniki.

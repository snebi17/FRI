# Aplikacijska Plast 
Aplikacijska plast je najbližja končnemu uporabniku, je dejanska aplikacija, ki jo ponavadi sprogramira programer in vsebuje uporabniški vmesnik in "*back-end*", ki je odgovorn za komunikacijo med enakovrednimi procesi.

Nekateri protokoli iz te plasti:
- telnet
- ssh
- FTP
- HTTP
- SNMP
# Predstavitvena in Sejna Plast
Te dve plasti po navadi predstavljamo skupaj, vendar sta na modelu različne.

Predstavitvena plast določa pomen podatkov med entitetnima paroma aplikacijske plasti. Določa sintakso in semantiko. Določa kodiranje, kompresiranje in varnostne mehanizme.

Medtem pa sejna plast določa nadzor pogovora, vpelje mehanizme za začenjanje, končanje in vzdrževanje seje. Logično povezovanje med aplikacijami, običajno vgrajena v aplikacijo.



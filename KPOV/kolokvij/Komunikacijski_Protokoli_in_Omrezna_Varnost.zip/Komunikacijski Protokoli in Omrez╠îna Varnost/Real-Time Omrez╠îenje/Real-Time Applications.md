Realni čas oz. stvarni čas, je čas, ki je definiran s terko:
- Čas dospetja dogodka
- Čas do začetka akcije glede na dogodek
- Potreben čas izvajanja 
- Rok zaključka izvajanja

Realni čas nam definira nov problem, kako ga zagotavljati v aplikacijah, tukaj pride do nove storitve.

Definiramo lahko tudi mehki in strogi realni čas (soft and hard real-time).
![[Pasted image 20221104153932.png]]
![[Pasted image 20221104160509.png]]

## Povezave
- [[Network Time Protocol]]
- 
DHCP je definiran z RFC 2131, obstajata različici za ipv4 in ipv6. 

DHCP kot protokol zagotavlja storitev dostopa do omrežja. Clientom dostavlja ip naslov, poleg ostalih podatkov, ki so recimo DNS strežnik, default gateway ipd.

>DHCP je dejansko neka vrsta nadgradnje BOOTP protokola (vsaj za ipv4), zato uporablja tudi UDP kot transportni protokol



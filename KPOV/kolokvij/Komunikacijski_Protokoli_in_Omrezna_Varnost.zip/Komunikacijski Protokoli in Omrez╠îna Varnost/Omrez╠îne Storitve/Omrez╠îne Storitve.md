## Povezave
- [[Domain Name System]]
- [[Dynamic Host Configuration Protocol]]
- [[Bootstrap Protocol]]
- [[Trivial File Transfer Protocol]]
- [[Simple Network Management Protocol]]

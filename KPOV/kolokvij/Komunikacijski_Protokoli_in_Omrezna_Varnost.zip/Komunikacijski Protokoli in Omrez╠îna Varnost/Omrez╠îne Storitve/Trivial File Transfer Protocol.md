TFTP je protokol za prenašanje datotek med dvema entitetama, definirian je v RFC 1350. 

TFTP je poenostavljen FTP protokol ravno za to uporabo, pri komunikacijah, kjer je izključno pomemben zgolj prenos datoteke, tako da je komunikacija čim lažja.

V njemu je pomembno to, kakšna operacija poteka, torej nalaganje ali jemanje podatkov. Potrditev prejema datoteke, piše zaporednje številke paketov, in pove kateri je zadnji.


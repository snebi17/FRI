**I**dentification - identifikacija; kdo je pravzaprav oseba (stroj) s katerim govorimo.
[[Authentication|Authentication]] - overovljenje; ali je to res ta oseba (računalnik), s katerim se pogovarjamo.
**A**uthorization - avtorizacija: ali ima oseba (stroj) s katero se pogovarjamo, pravico do vira/storitve
**A**ccounting - beleženje


Eden izmed protokolov, ki skrbi za AAA je [[RADIUS]].
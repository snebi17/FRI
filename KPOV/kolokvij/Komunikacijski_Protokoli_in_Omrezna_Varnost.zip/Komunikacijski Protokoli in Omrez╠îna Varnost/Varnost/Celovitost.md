Celovitost je postopek zagotavljanja, **da se paket tak, kot je poslan tudi prikaže in pojavi na drugi strani komunikacije**. Torej zagotavjamo, da vmes ni bil spremenjen.

![[Pasted image 20230111182423.png]]

>Kljub uporabi take funkcije, je sistem ranljiv proti:
>	Napadalčevem vpogledu
>	Zavračanjem paketa
>	Napadom z podvajanjem


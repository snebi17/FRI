Tako, kot RFC-ji definirajo protokole ipd. in jih vzdržujejo IETF. Je tudi IEEE neke vrste standardov, ki jih pa definiria točno IEEE - **I**nstitute of **E**lectrical and **E**lectronics **E**ngineers.

Motivacija za snov: Laptop skušamo priklopiti na internet.
![[Pasted image 20230113101211.png]]
Pri čemer ne bomo definirali elemente, kot fizične naprave, vendar bomo rekli, da je ta zelen krog neka **storitev**, ki ponuja laptop-u, da se priklopi na internet.

Poleg tega da je to storitev za dostop do Interneta, mora omogočati oz. tudi zahtevati 